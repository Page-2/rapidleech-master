<?php
$upload_services[] = 'upvast.com';
$max_file_size['upvast.com'] = 5072;
$page_upload['upvast.com'] = 'upvast.com.php';  
?>