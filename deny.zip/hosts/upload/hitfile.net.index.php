<?
$upload_services[]="hitfile.net";
$max_file_size["hitfile.net"]= 100000;
$page_upload["hitfile.net"] = "hitfile.net.php";
?>
