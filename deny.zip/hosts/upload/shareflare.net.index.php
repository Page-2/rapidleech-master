<?php 
$upload_services[] = "shareflare.net";
$max_file_size["shareflare.net"] = 200;
$page_upload["shareflare.net"] = "shareflare.net.php";  
?>