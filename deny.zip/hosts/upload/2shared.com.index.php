<?php 
$upload_services[]="2shared.com";
$max_file_size["2shared.com"]=1000;
$page_upload["2shared.com"] = "2shared.com.php";
?>